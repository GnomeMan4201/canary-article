---
title: The Art of the Canary in the Age of AI
published: false
tags: ai, testing, programming, devops
---

![A yellow canary, software terminal, and separate checklist surrounded by psychedelic pop-art birds and hand-drawn shapes.](assets/canary-cover-psychedelic.png)

The first completed pilot run produced exactly the signal we had asked for:

```text
CANARY:fd11c73f1ba333de
```

Then the agent explained that it couldn't access the project files or run checks. Our container was missing an execution helper, `codex-code-mode-host`. The requested feature had not been implemented.

The canary was present. The work could not proceed.

That was an infrastructure failure in our pilot, not a discovered booking bug or a result from the main experiment. The distinction became the first useful lesson of the project: a visible signal needs a precise meaning.

We preserved the failed pilot, documented the runtime defect, and started a replacement cohort after fixing it. You can inspect the [original response](../artifacts/pilot-01/runs/reschedule-01-B/final.txt), [independent evaluation](../artifacts/pilot-01/runs/reschedule-01-B/result.json), and [amendment](../artifacts/pilot-01/amendment.json).

The question behind the experiment survived: **what does an instruction canary actually tell us about an AI coding agent's work?**

## A small signal with a long history

Mining canaries responded to dangerous gases before their human handlers did. One detail makes that history more interesting than the familiar metaphor: the Science Museum holds a canary cage equipped with an oxygen cylinder. Its design allowed a poisoned bird to be enclosed and given oxygen. Detection was connected to a response. [Science Museum collection](https://collection.sciencemuseumgroup.org.uk/objects/co8412250/cage-for-reviving-canary)

Software borrowed the canary metaphor. A deployment canary exposes a limited population to a change and evaluates it against a control before a wider rollout. Google's SRE workbook describes both the rollout and the evaluation needed to make that useful. [Canarying Releases](https://sre.google/workbook/canarying-releases/)

An **instruction canary** uses a different mechanism. We place a small requirement in project instructions and look for its observable effect: perhaps a recognizable word at the start of the agent's response.

That output proves something narrow: the response satisfied that particular requirement. Establishing a relationship to other behavior takes additional evidence.

This technique already has implementations. [Context Canary](https://github.com/Nachx639/context-canary) displays a bird associated with a response marker and supports checkpoints distributed through instructions. Its documentation also explains that a missing marker does not prove context loss. Our contribution is a reproducible experiment that puts the marker beside independent checks of the resulting code.

## Give the canary one clear job

Here is the instruction used in our marker condition, with an example token:

```text
The first nonempty line of your final response must be exactly
CANARY:0123456789abcdef, with no other characters on that line.
Put all other text on subsequent lines.
```

It belongs in a project instruction file supported by the chosen coding tool. For Codex, `AGENTS.md` participates in a documented discovery chain with project and global scopes. Verify the applicable location and overrides for your tool; an instruction sitting on disk is not automatically evidence that it reached the model. [Codex instruction discovery](https://learn.chatgpt.com/docs/agent-configuration/agents-md)

Our runner generates a different token for every marker run. It puts that instruction in `AGENTS.md`, without repeating the token in the task prompt. The scorer checks the terminal final response, excluding tool output and intermediate messages.

We distinguish exact matches, malformed occurrences, absent tokens, and unobserved final responses. A timeout with no final response is not the same observation as a response that omitted its marker.

We also keep four questions separate:

- What evidence shows that the instructions were loaded?
- Did the final response satisfy the marker instruction?
- Did the resulting code pass the specified behavioral checks?
- Was the requested feature actually completed?

Instruction context and enforcement are different mechanisms. Anthropic makes that distinction explicitly in its memory documentation, which also describes loading diagnostics and hooks. [How Claude remembers your project](https://code.claude.com/docs/en/memory)

## Build something worth checking

Our experimental subject is a small Python booking module with two meeting rooms. It has no database, web server, or current-time dependency. That keeps the work small enough to inspect while giving mistakes a concrete meaning.

Its contract includes three important rules: reservations for the same room must not overlap; timestamps must carry an explicit offset and be normalized to UTC; rejected operations must leave existing bookings unchanged.

Adjacent reservations are allowed. Different rooms may be booked at the same time. These details are written down before the agent starts, because hidden checks should exercise a published contract rather than introduce surprise requirements.

Each run starts from the same working baseline and gets one task:

1. Add rescheduling while preserving a booking's identity and room.
2. Return the rooms available during a requested interval.
3. Add a batch of reservations atomically, so one invalid member prevents the entire batch from being saved.

The [fixture contract](../docs/contract.md) defines the API and edge cases. The tasks are independent; a later task does not inherit an earlier agent's implementation.

## Test the measuring equipment

Before measuring agents, we calibrated the evaluator with **16 cases**. They include correct implementations, deliberately broken overlap and timestamp handling, partial batch writes, missing features, import failures, and an import that hangs.

All 16 met their calibration expectations. That means the evaluator recognized the expected outcomes; it does not mean the deliberately broken programs passed the booking checks. For the hanging import, the expected outcome was a timeout with unevaluable behavior and verified container cleanup. These cases are test equipment validation, not model runs. [Calibration record](../artifacts/calibration/summary.json)

The agent can see public examples. Evaluator-owned checks and reference implementations remain outside its container. After the agent stops, the saved submission runs in a separate evaluation container without network access or credentials.

This arrangement also keeps the agent's claim that tests passed separate from the evaluator's evidence. A feature can be missing even while the original baseline still passes its existing-operation checks—as our failed runtime pilot demonstrated.

After repairing that runtime, we completed six replacement pilot runs: one marker and one no-marker run for each task. All six passed their independent rule and feature checks; all three marker responses matched exactly. Those pilots checked that the procedure worked. They remain outside the main dataset. [Replacement pilot report](../artifacts/pilot-02/report/report.html)

## Freeze the comparison before reading the result

The main plan contains **30 attempts**: three tasks, two conditions, and five repetitions. Fifteen runs receive the marker instruction. The other fifteen receive the same project rules without it.

We randomize task/repetition blocks and the order of the two conditions within each block. Sessions and workspaces start fresh. This study uses Codex CLI 0.166.0, the `gpt-6-astra` model alias, high reasoning effort, and a 240-second limit per attempt. The saved plan records those settings, the runtime image, source hashes, and execution order. The underlying provider backend revision is unavailable, which limits exact model reproducibility.

We froze the plan before main collection. Failed attempts remain in the ledger rather than being silently retried or replaced. This is a local audit trail, not a public preregistration.

Thirty attempts are a small exploratory case study. Repeated calls to the same model do not establish independent samples, and hundreds of test assertions do not turn one agent run into hundreds of observations. [Full protocol](../docs/experiment.md)

## The result was uniformly green

All **30 main attempts completed**. Every submission built and passed both its feature-acceptance and project-rule checks. There were no main-study timeouts, interrupted attempts, missing final responses, or unevaluable results.

| Task | No marker: feature and rule checks passed | With marker: feature and rule checks passed | Exact markers |
| --- | --- | --- | --- |
| Rescheduling | 5/5 | 5/5 | 5/5 |
| Availability | 5/5 | 5/5 | 5/5 |
| Atomic batch booking | 5/5 | 5/5 | 5/5 |

Among the fifteen marker-enabled runs, the table was equally simple:

| Marker instruction | Rule checks passed | Rule checks failed |
| --- | --- | --- |
| Exact match | 15 | 0 |
| Noncompliant marker | 0 | 0 |

The fifteen no-marker controls do not belong in that second table. Their feature and rule outcomes remain in the first one. None of the marker runs were excluded for unavailable evidence. [Complete main-study report](../artifacts/main-01/report/report.html)

For a representative example, [reschedule-01-B](../artifacts/main-01/runs/reschedule-01-B/result.json) returned its exact marker and passed the independent checks. All fifteen marker-enabled runs shared that overall outcome.

This supports a narrow observation: the marker format was followed in every marker-enabled run in this setup. **It does not establish the marker's value as a warning signal.** We saw neither a marker omission nor a checked rule failure, so we cannot compare failure rates between compliant and noncompliant responses. The fraction of failures accompanied by a warning is undefined because there were no observed failures.

These were short edits to a working baseline that already supplied timestamp normalization and conflict-checking helpers. We did not test long-session drift or large architectural changes. Automatic instruction-loading diagnostics were unavailable, although pilot transcripts recorded explicit reads of `AGENTS.md`. We kept the fixed tasks and sample rather than increasing difficulty until a disagreement appeared. A study of warning lead time would need a different, longitudinal design.

## Make the evidence easy to inspect

The companion project, Canary Lab, produces a standalone HTML report and machine-readable JSON. Each planned run stays visible. Marker status, feature completion, rule checks, and missing evidence have separate fields. The [evidence explorer](../artifacts/main-01/explorer.html) lets you filter by task or condition and expand a run's instructions, prompt, final response, code diff, and evaluation.

Saved submissions can be evaluated again without another model call. That makes the project useful beyond the article: readers can investigate a surprising result or adapt the contract to their own project. The [run guide](../docs/running.md) covers setup, calibration, pilots, collection, and replay.

## What I would put in a real project

Start with one cheap, unambiguous marker and a specific question about instruction handling. Confirm how your tool loads it. Keep the marker easy to recognize and avoid treating a general “rules followed” statement as evidence for every rule.

Pair it with a check of the behavior you care about. If the concern is overlapping reservations, exercise overlapping reservations. If a requirement must hold at a particular tool boundary, consider an appropriate enforcement mechanism there.

Decide what an omission should prompt. Inspect loading diagnostics, check for conflicting instructions, re-establish the relevant requirement, and run its independent check. These are proposed engineering practices; this experiment does not compare recovery strategies or rank canary designs.

The craft is in matching a small signal to a question it can help answer—and keeping the evidence that answers the larger questions beside it.
