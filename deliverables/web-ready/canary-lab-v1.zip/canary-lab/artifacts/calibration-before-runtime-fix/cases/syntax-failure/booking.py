def broken(
